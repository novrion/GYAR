#include "search.h"



int main() {

  PlayBot();

  char c;
  std::cin >> c;





  return 0;
}